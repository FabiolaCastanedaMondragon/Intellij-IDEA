package com.tesji.proyectoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoApiTesjiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoApiTesjiApplication.class, args);
	}

}
